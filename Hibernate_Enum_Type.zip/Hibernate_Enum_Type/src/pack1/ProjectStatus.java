package pack1;

public enum ProjectStatus {
	COMPLETED,PROGRESS;
	
}
